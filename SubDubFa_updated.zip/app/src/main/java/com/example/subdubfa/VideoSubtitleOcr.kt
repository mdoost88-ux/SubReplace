package com.example.subdubfa

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.Locale

object VideoSubtitleOcr {

    private data class Reading(
        val time: Long,
        val text: String,
        val x: Float,
        val y: Float,
        val width: Float,
        val height: Float
    )

    fun scan(
        context: Context,
        uri: Uri,
        intervalMs: Long = 450L,
        onProgress: (Int) -> Unit
    ): List<Cue> {
        val retriever = MediaMetadataRetriever()
        val recognizer = TextRecognition.getClient(
            TextRecognizerOptions.DEFAULT_OPTIONS
        )

        try {
            retriever.setDataSource(context, uri)
            val duration = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_DURATION
            )?.toLongOrNull() ?: error("مدت ویدئو قابل تشخیص نیست")

            require(duration > 0) { "ویدئوی خالی است" }

            val readings = mutableListOf<Reading>()
            var at = 0L

            while (at < duration) {
                val bitmap = retriever.getFrameAtTime(
                    at * 1000,
                    MediaMetadataRetriever.OPTION_CLOSEST
                )

                if (bitmap != null) {
                    try {
                        val result = Tasks.await(
                            recognizer.process(InputImage.fromBitmap(bitmap, 0))
                        )
                        val lines = result.textBlocks.flatMap { it.lines }
                            .mapNotNull { line ->
                                val box = line.boundingBox ?: return@mapNotNull null
                                val text = line.text.trim()
                                val centerY = box.centerY().toFloat() / bitmap.height

                                if (!isUseful(text) || centerY !in 0.45f..0.98f) {
                                    return@mapNotNull null
                                }

                                Reading(
                                    at, text,
                                    box.left.toFloat() / bitmap.width,
                                    box.top.toFloat() / bitmap.height,
                                    box.width().toFloat() / bitmap.width,
                                    box.height().toFloat() / bitmap.height
                                )
                            }

                        if (lines.isNotEmpty()) {
                            val text = lines.joinToString(" ") { it.text }
                            readings += Reading(
                                at, text,
                                lines.minOf { it.x },
                                lines.minOf { it.y },
                                lines.maxOf { it.x + it.width } - lines.minOf { it.x },
                                lines.maxOf { it.y + it.height } - lines.minOf { it.y }
                            )
                        }
                    } finally {
                        bitmap.recycle()
                    }
                }

                at += intervalMs
                onProgress(((at * 100) / duration).toInt().coerceIn(0, 100))
            }

            return groupReadings(readings, intervalMs)
        } finally {
            recognizer.close()
            retriever.release()
        }
    }

    private fun isUseful(text: String): Boolean =
        text.length >= 2 && text.any { it.isLetterOrDigit() }

    private fun normalize(text: String): String =
        text.lowercase(Locale.ROOT)
            .replace(Regex("[^\\p{L}\\p{N} ]"), "")
            .replace(Regex("\\s+"), " ")
            .trim()

    private fun groupReadings(
        readings: List<Reading>,
        interval: Long
    ): List<Cue> {
        if (readings.isEmpty()) return emptyList()

        val groups = mutableListOf<MutableList<Reading>>()

        readings.forEach { item ->
            val last = groups.lastOrNull()
            if (last != null &&
                normalize(last.last().text) == normalize(item.text) &&
                item.time - last.last().time <= interval * 2.5
            ) {
                last += item
            } else {
                groups += mutableListOf(item)
            }
        }

        return groups.mapIndexedNotNull { index, group ->
            val text = group.maxByOrNull { it.text.length }
                ?.text?.trim().orEmpty()
            if (text.length < 2) null else Cue(
                index + 1,
                Srt.timestamp(group.first().time),
                Srt.timestamp(group.last().time + interval),
                text,
                group.map { it.x }.average().toFloat(),
                group.map { it.y }.average().toFloat(),
                group.map { it.width }.average().toFloat(),
                group.map { it.height }.average().toFloat()
            )
        }
    }
}
