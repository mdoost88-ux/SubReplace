package com.example.subdubfa

data class Cue(val index: Int, val start: String, val end: String, val text: String)

object Srt {
    private val block = Regex("(?m)^(\\d+)\\s*\\r?\\n(\\d{2}:\\d{2}:\\d{2}[,.]\\d{3})\\s*-->\\s*(\\d{2}:\\d{2}:\\d{2}[,.]\\d{3})\\s*\\r?\\n([\\s\\S]*?)(?=\\r?\\n\\s*\\r?\\n|\\$)")
    fun parse(raw: String): List<Cue> = block.findAll(raw.trim()).map { m ->
        Cue(m.groupValues[1].toInt(), m.groupValues[2].replace(',', '.'), m.groupValues[3].replace(',', '.'), m.groupValues[4].trim())
    }.toList()

    fun render(cues: List<Cue>, translated: List<String>, bilingual: Boolean = true): String = cues.mapIndexed { i, c ->
        val fa = translated.getOrNull(i).orEmpty()
        "${i + 1}\n${c.start.replace('.', ',')} --> ${c.end.replace('.', ',')}\n" +
            (if (bilingual && fa.isNotBlank()) "${c.text}\n$fa" else if (fa.isNotBlank()) fa else c.text)
    }.joinToString("\n\n") + "\n"
}
