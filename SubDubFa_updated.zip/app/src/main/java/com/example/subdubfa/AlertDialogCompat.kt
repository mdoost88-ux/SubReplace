package com.example.subdubfa

import android.content.Context
import android.widget.EditText
import androidx.appcompat.app.AlertDialog

object AlertDialogCompat {
    fun show(context: Context, title: String, input: EditText, onSave: () -> Unit) {
        AlertDialog.Builder(context).setTitle(title).setView(input)
            .setPositiveButton("اعمال تغییرات") { _, _ -> onSave() }
            .setNegativeButton("انصراف", null).show()
    }
}
