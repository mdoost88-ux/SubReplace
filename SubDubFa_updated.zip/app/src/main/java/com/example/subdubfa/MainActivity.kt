package com.example.subdubfa

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.edit
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import org.json.JSONArray
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private val executor = Executors.newSingleThreadExecutor()
    private var videoUri: Uri? = null
    private var srtUri: Uri? = null
    private var cues: List<Cue> = emptyList()
    private var translated: List<String> = emptyList()
    private lateinit var status: TextView
    private lateinit var endpoint: EditText
    private lateinit var key: EditText
    private lateinit var model: EditText
    private lateinit var bilingual: CheckBox

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 24) }
        root.addView(TextView(this).apply { text = "SubDub فارسی — نسخه آزمایشی"; textSize = 22f; gravity = Gravity.CENTER })
        root.addView(button("انتخاب ویدئو") { pickVideo() })
        root.addView(button("انتخاب زیرنویس انگلیسی SRT") { pickSrt() })
        endpoint = field("آدرس API سازگار با OpenAI (…/v1/chat/completions)", prefs.getString("endpoint", "") ?: "")
        key = field("کلید API شخصی", prefs.getString("key", "") ?: "", true)
        model = field("نام مدل", prefs.getString("model", "gpt-4o-mini") ?: "gpt-4o-mini")
        root.addView(endpoint); root.addView(key); root.addView(model)
        bilingual = CheckBox(this).apply { text = "نمایش انگلیسی بالا و فارسی پایین"; isChecked = true }
        root.addView(bilingual)
        root.addView(button("ترجمه زیرنویس به فارسی") { translateSrt() })
        root.addView(button("ذخیره SRT دوزبانه") { saveBilingualSrt() })
        root.addView(button("ساخت MP4 با زیرنویس چسبیده") { renderVideo() })
        status = TextView(this).apply { text = "ابتدا ویدئو و فایل SRT را انتخاب کن."; textSize = 15f }
        root.addView(status)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun field(hintText: String, value: String, secret: Boolean = false): EditText = EditText(this).apply {
        hint = hintText; setText(value); textSize = 14f
        if (secret) inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
    }
    private fun button(label: String, action: () -> Unit) = Button(this).apply { text = label; setOnClickListener { action() } }
    private fun pickVideo() = picker("video/*", 10)
    private fun pickSrt() = picker("application/x-subrip", 11)
    private fun picker(type: String, code: Int) { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).setType(type).addCategory(Intent.CATEGORY_OPENABLE), code) }

    @Deprecated("Legacy picker callback retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK) return
        val uri = data?.data ?: return
        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        if (requestCode == 10) { videoUri = uri; say("ویدئو انتخاب شد.") }
        if (requestCode == 12) {
            val src = pendingSrt ?: return
            try { contentResolver.openOutputStream(uri)?.use { out -> src.inputStream().use { it.copyTo(out) } }; say("فایل SRT ذخیره شد.") }
            catch (e: Exception) { say("خطا در ذخیره SRT: ${e.message}") }
        }
        if (requestCode == 13) {
            val src = pendingVideo ?: return
            try { contentResolver.openOutputStream(uri)?.use { out -> src.inputStream().use { it.copyTo(out) } }; say("ویدئوی MP4 آماده و ذخیره شد.") }
            catch (e: Exception) { say("خطا در ذخیره ویدئو: ${e.message}") }
        }
        if (requestCode == 11) {
            srtUri = uri
            try {
                val raw = contentResolver.openInputStream(uri)!!.bufferedReader(Charsets.UTF_8).use { it.readText() }
                cues = Srt.parse(raw)
                translated = emptyList()
                say("${cues.size} زیرنویس شناسایی شد.")
            } catch (e: Exception) { say("خطا در خواندن SRT: ${e.message}") }
        }
    }

    private fun translateSrt() {
        if (cues.isEmpty()) { say("ابتدا فایل SRT معتبر انتخاب کن."); return }
        val url = endpoint.text.toString().trim(); val token = key.text.toString().trim(); val mdl = model.text.toString().trim()
        if (url.isBlank() || mdl.isBlank()) { say("آدرس API و نام مدل را وارد کن."); return }
        getSharedPreferences("settings", MODE_PRIVATE).edit { putString("endpoint", url); putString("key", token); putString("model", mdl) }
        say("ترجمه در حال انجام است…")
        executor.execute {
            try {
                val output = mutableListOf<String>()
                // Small batches avoid oversized requests and retain cue order.
                cues.chunked(20).forEach { batch -> output += Translator.translate(batch.map { it.text }, url, token, mdl) }
                translated = output
                runOnUiThread { say("ترجمه ${output.size} خط کامل شد.") }
            } catch (e: Exception) { runOnUiThread { say("خطای ترجمه: ${e.message}") } }
        }
    }

    private fun saveBilingualSrt() {
        if (cues.isEmpty() || translated.size != cues.size) { say("ابتدا ترجمه را کامل کن."); return }
        val text = Srt.render(cues, translated, bilingual.isChecked)
        val file = File(cacheDir, "subdub_fa_bilingual.srt").apply { writeText(text, Charsets.UTF_8) }
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).setType("application/x-subrip").putExtra(Intent.EXTRA_TITLE, "subdub_fa_bilingual.srt")
        pendingSrt = file
        startActivityForResult(intent, 12)
    }
    private var pendingSrt: File? = null

    private fun renderVideo() {
        val vu = videoUri
        if (vu == null || cues.isEmpty() || translated.size != cues.size) { say("ویدئو و ترجمه کامل لازم است."); return }
        say("آماده‌سازی فایل‌ها برای خروجی…")
        executor.execute {
            try {
                val input = File(cacheDir, "source_video").apply { outputStream().use { out -> contentResolver.openInputStream(vu)!!.use { it.copyTo(out) } } }
                val en = File(cacheDir, "english.srt").apply { writeText(Srt.render(cues, List(cues.size) { "" }, false), Charsets.UTF_8) }
                val fa = File(cacheDir, "persian.srt").apply { writeText(Srt.render(cues, translated, false), Charsets.UTF_8) }
                val out = File(cacheDir, "subdub_output.mp4")
                val enPath = en.absolutePath.replace("\\", "\\\\").replace(":", "\\:").replace("'", "\\'")
                val faPath = fa.absolutePath.replace("\\", "\\\\").replace(":", "\\:").replace("'", "\\'")
                val filter = "subtitles='$enPath':force_style='FontName=Arial,FontSize=18,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,BorderStyle=1,Outline=2,Alignment=8'[v1];[v1]subtitles='$faPath':force_style='FontName=Noto Naskh Arabic,FontSize=22,PrimaryColour=&H0000FFFF,OutlineColour=&H00000000,BorderStyle=1,Outline=2,Alignment=2'[v]"
                val cmd = "-y -i '${input.absolutePath}' -filter_complex \"$filter\" -map \"[v]\" -map 0:a? -c:v libx264 -preset veryfast -crf 23 -c:a copy -movflags +faststart '${out.absolutePath}'"
                val session = FFmpegKit.execute(cmd)
                if (!ReturnCode.isSuccess(session.returnCode)) error("FFmpeg failed: ${session.failStackTrace ?: session.returnCode}")
                runOnUiThread { exportVideo(out) }
            } catch (e: Exception) { runOnUiThread { say("خطای خروجی: ${e.message}") } }
        }
    }

    private fun exportVideo(file: File) {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).setType("video/mp4").putExtra(Intent.EXTRA_TITLE, "subdub_fa_output.mp4")
        pendingVideo = file
        startActivityForResult(intent, 13)
    }
    private var pendingVideo: File? = null

    private fun say(message: String) { status.text = message }
}
