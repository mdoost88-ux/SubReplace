package com.example.subdubfa

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.edit
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import java.io.File
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private val executor = Executors.newSingleThreadExecutor()
    private var videoUri: Uri? = null
    private var cues: List<Cue> = emptyList()
    private var translated: List<String> = emptyList()
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var endpoint: EditText
    private lateinit var key: EditText
    private lateinit var model: EditText
    private lateinit var bilingual: CheckBox
    private var pendingSrt: File? = null
    private var pendingVideo: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 22, 22, 28)
            setBackgroundColor(Color.rgb(12, 18, 31))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        root.addView(TextView(this).apply {
            text = "SubDub فارسی\nترجمه و زیرنویس هوشمند فیلم"
            textSize = 25f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(8, 20, 8, 24)
        })
        root.addView(label("۱. انتخاب ویدئو"))
        root.addView(button("انتخاب فیلم از گوشی") { pickVideo() })
        root.addView(button("تشخیص زیرنویس چسبیده با OCR") { scanVideo() })
        root.addView(button("یا وارد کردن فایل زیرنویس SRT") { pickSrt() })
        root.addView(label("۲. ترجمه هوشمند"))
        endpoint = field("نشانی API سازگار با OpenAI", prefs.getString("endpoint", "") ?: "")
        key = field("کلید API (فقط تا پایان اجرای برنامه نگهداری می‌شود)", "", true).apply { isSaveEnabled = false }
        model = field("نام مدل", prefs.getString("model", "gpt-4o-mini") ?: "gpt-4o-mini")
        root.addView(endpoint); root.addView(key); root.addView(model)
        root.addView(button("ترجمه انگلیسی به فارسی محاوره‌ای") { translateSrt() })
        root.addView(label("۳. بازبینی و خروجی"))
        bilingual = CheckBox(this).apply { text = "در فایل SRT هر دو زبان نمایش داده شوند"; isChecked = true; setTextColor(Color.WHITE) }
        root.addView(bilingual)
        root.addView(button("ویرایش متن‌های تشخیص‌داده‌شده / ترجمه") { editCues() })
        root.addView(button("ذخیره فایل SRT") { saveSrt(false) })
        root.addView(button("ذخیره SRT دوزبانه") { saveSrt(true) })
        root.addView(button("ساخت MP4 با افزودن زیرنویس فارسی") { renderVideo() })
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE }
        root.addView(progress)
        status = TextView(this).apply {
            text = "برای شروع، یک فیلم انتخاب کن. OCR متن زیرنویس انگلیسیِ چسبیده را از بخش پایین تصویر نمونه‌برداری می‌کند."
            textSize = 14f; setTextColor(Color.rgb(220, 226, 238)); setPadding(4, 18, 4, 12)
        }
        root.addView(status)
        setContentView(ScrollView(this).apply { setBackgroundColor(Color.rgb(12, 18, 31)); addView(root) })
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text; textSize = 17f; setTextColor(Color.rgb(111, 190, 255)); setPadding(4, 22, 4, 8)
    }
    private fun field(hintText: String, value: String, secret: Boolean = false) = EditText(this).apply {
        hint = hintText; setText(value); textSize = 14f; setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
        if (secret) inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
    }
    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 14f; setOnClickListener { action() }
    }
    private fun say(message: String) { status.text = message }
    private fun pickVideo() = picker("video/*", 10)
    private fun pickSrt() = picker("application/x-subrip", 11)
    private fun picker(type: String, code: Int) {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).setType(type)
            .addCategory(Intent.CATEGORY_OPENABLE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), code)
    }

    @Deprecated("Legacy picker callback retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK) return
        val uri = data?.data ?: return
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
        when (requestCode) {
            10 -> { videoUri = uri; say("ویدئو انتخاب شد. برای استخراج متن انگلیسی، تشخیص OCR را اجرا کن.") }
            11 -> try {
                val raw = contentResolver.openInputStream(uri)!!.bufferedReader(Charsets.UTF_8).use { it.readText() }
                cues = Srt.parse(raw); translated = emptyList(); say("${cues.size} زیرنویس از فایل SRT خوانده شد.")
            } catch (e: Exception) { say("خطا در خواندن SRT: ${e.message}") }
            12 -> exportFile(pendingSrt, uri, "فایل SRT ذخیره شد.")
            13 -> exportFile(pendingVideo, uri, "ویدئوی MP4 ذخیره شد.")
        }
    }

    private fun scanVideo() {
        val uri = videoUri ?: run { say("ابتدا ویدئو را انتخاب کن."); return }
        setBusy(true, "در حال بررسی فریم‌های فیلم با OCR…")
        executor.execute {
            try {
                val found = VideoSubtitleOcr.scan(this, uri) { value -> runOnUiThread { progress.progress = value; say("تشخیص زیرنویس: $value٪") } }
                runOnUiThread {
                    cues = found; translated = emptyList(); setBusy(false, "تشخیص تمام شد: ${found.size} قطعه زیرنویس پیدا شد. متن را بازبینی کن.")
                }
            } catch (e: Exception) { runOnUiThread { setBusy(false, "خطای OCR: ${e.message}") } }
        }
    }

    private fun translateSrt() {
        if (cues.isEmpty()) { say("ابتدا زیرنویس را با OCR استخراج یا فایل SRT را وارد کن."); return }
        val url = endpoint.text.toString().trim(); val token = key.text.toString().trim(); val mdl = model.text.toString().trim()
        if (url.isBlank() || mdl.isBlank()) { say("نشانی API و نام مدل را وارد کن."); return }
        getSharedPreferences("settings", MODE_PRIVATE).edit { putString("endpoint", url); putString("model", mdl) }
        setBusy(true, "ترجمه در حال انجام است…")
        executor.execute {
            try {
                val output = mutableListOf<String>()
                cues.chunked(20).forEach { batch -> output += Translator.translate(batch.map { it.text }, url, token, mdl) }
                translated = output
                runOnUiThread { setBusy(false, "ترجمه ${output.size} قطعه کامل شد. می‌توانی متن‌ها را ویرایش کنی.") }
            } catch (e: Exception) { runOnUiThread { setBusy(false, "خطای ترجمه: ${e.message}") } }
        }
    }

    private fun editCues() {
        if (cues.isEmpty()) { say("هنوز زیرنویسی برای ویرایش وجود ندارد."); return }
        val content = cues.mapIndexed { i, cue ->
            "${i + 1} | ${cue.start} --> ${cue.end}\nEN: ${cue.text}\nFA: ${translated.getOrNull(i).orEmpty()}"
        }.joinToString("\n\n")
        val input = EditText(this).apply { setText(content); minLines = 12; gravity = Gravity.TOP; textSize = 13f }
        AlertDialogCompat.show(this, "بازبینی زیرنویس", input) {
            val edited = input.text.toString().split(Regex("\\n\\s*\\n"))
            val updatedCues = cues.toMutableList()
            val updatedTranslations = translated.toMutableList()
            edited.forEachIndexed { i, block ->
                if (i < cues.size) {
                    val lines = block.lines()
                    val timing = Regex("(\\d{2}:\\d{2}:\\d{2}[,.]\\d{3})\\s*-->\\s*(\\d{2}:\\d{2}:\\d{2}[,.]\\d{3})")
                        .find(block)
                    val enLine = lines.indexOfFirst { it.startsWith("EN:") }
                    val faLine = lines.indexOfFirst { it.startsWith("FA:") }
                    val en = if (enLine >= 0) (listOf(lines[enLine].removePrefix("EN:").trimStart()) +
                        lines.subList(enLine + 1, if (faLine > enLine) faLine else lines.size)).joinToString("\n").trim() else cues[i].text
                    val fa = if (faLine >= 0) (listOf(lines[faLine].removePrefix("FA:").trimStart()) +
                        lines.drop(faLine + 1)).joinToString("\n").trim() else updatedTranslations.getOrNull(i).orEmpty()
                    val old = cues[i]
                    updatedCues[i] = old.copy(
                        start = timing?.groupValues?.get(1)?.replace(',', '.') ?: old.start,
                        end = timing?.groupValues?.get(2)?.replace(',', '.') ?: old.end,
                        text = en.ifBlank { old.text }
                    )
                    while (updatedTranslations.size <= i) updatedTranslations.add("")
                    updatedTranslations[i] = fa
                }
            }
            cues = updatedCues
            if (updatedTranslations.any { it.isNotBlank() }) translated = updatedTranslations
            say("ویرایش متن و زمان‌بندی اعمال شد.")
        }
    }

    private fun saveSrt(both: Boolean) {
        if (cues.isEmpty()) { say("زیرنویسی برای ذخیره وجود ندارد."); return }
        if (both && translated.size != cues.size) { say("برای خروجی دوزبانه ابتدا ترجمه را کامل کن."); return }
        val content = Srt.render(cues, translated, both)
        val file = File(cacheDir, "subdub_${if (both) "bilingual" else "persian"}.srt").apply { writeText(content, Charsets.UTF_8) }
        pendingSrt = file
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).setType("application/x-subrip")
            .putExtra(Intent.EXTRA_TITLE, file.name), 12)
    }

    private fun renderVideo() {
        val uri = videoUri
        if (uri == null || cues.isEmpty() || translated.size != cues.size) { say("ویدئو و ترجمه کامل لازم است."); return }
        setBusy(true, "در حال آماده‌سازی و رندر ویدئو…")
        executor.execute {
            try {
                val input = File(cacheDir, "source_video.mp4").apply { outputStream().use { out -> contentResolver.openInputStream(uri)!!.use { it.copyTo(out) } } }
                val fa = File(cacheDir, "persian.srt").apply { writeText(Srt.render(cues, translated, false), Charsets.UTF_8) }
                val out = File(cacheDir, "subdub_output.mp4")
                val path = fa.absolutePath.replace("\\", "\\\\").replace(":", "\\:").replace("'", "\\'")
                // The original English hardcoded subtitle remains in the source picture; only Persian is added.
                val filter = "subtitles='$path':force_style='FontName=Arial,FontSize=22,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,BorderStyle=1,Outline=2,Alignment=2,MarginV=22'"
                val cmd = "-y -i '${input.absolutePath}' -vf \"$filter\" -map 0:v:0 -map 0:a? -c:v libx264 -preset veryfast -crf 23 -c:a copy -movflags +faststart '${out.absolutePath}'"
                val session = FFmpegKit.execute(cmd)
                if (!ReturnCode.isSuccess(session.returnCode)) error("FFmpeg: ${session.failStackTrace ?: session.returnCode}")
                runOnUiThread { setBusy(false, "رندر تمام شد؛ محل ذخیره را انتخاب کن."); pendingVideo = out
                    startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).setType("video/mp4").putExtra(Intent.EXTRA_TITLE, "subdub_fa_output.mp4"), 13) }
            } catch (e: Exception) { runOnUiThread { setBusy(false, "خطای خروجی ویدئو: ${e.message}") } }
        }
    }

    private fun exportFile(file: File?, uri: Uri, success: String) {
        try { val src = file ?: error("فایل خروجی پیدا نشد"); contentResolver.openOutputStream(uri)?.use { out -> src.inputStream().use { it.copyTo(out) } }; say(success) }
        catch (e: Exception) { say("خطا در ذخیره: ${e.message}") }
    }
    private fun setBusy(busy: Boolean, message: String) {
        progress.visibility = if (busy) View.VISIBLE else View.GONE
        if (!busy) progress.progress = 0
        say(message)
    }
    override fun onDestroy() { executor.shutdownNow(); super.onDestroy() }
}
