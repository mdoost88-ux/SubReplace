package com.example.subdubfa

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** OpenAI-compatible endpoint. User supplies their own endpoint and API key. */
object Translator {
    fun translate(texts: List<String>, endpoint: String, apiKey: String, model: String): List<String> {
        require(endpoint.startsWith("https://")) { "Endpoint must use HTTPS" }
        val prompt = "Translate each subtitle line from English to natural conversational Persian. Keep names and meaning. Return ONLY a JSON array of Persian strings in the same order. Do not merge or split lines.\n" + JSONArray(texts).toString()
        val body = JSONObject().put("model", model).put("temperature", 0.2)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt))).toString()
        val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 30000; readTimeout = 120000; doOutput = true
            setRequestProperty("Content-Type", "application/json")
            if (apiKey.isNotBlank()) setRequestProperty("Authorization", "Bearer $apiKey")
        }
        conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val response = (if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream).bufferedReader().use { it.readText() }
        if (conn.responseCode !in 200..299) error("Translation API ${conn.responseCode}: $response")
        val content = JSONObject(response).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
        val json = content.substring(content.indexOf('['), content.lastIndexOf(']') + 1)
        val arr = JSONArray(json)
        require(arr.length() == texts.size) { "Translation returned ${arr.length()} lines; expected ${texts.size}" }
        return (0 until arr.length()).map { arr.getString(it) }
    }
}
