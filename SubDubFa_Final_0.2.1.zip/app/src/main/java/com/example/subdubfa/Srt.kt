package com.example.subdubfa

data class Cue(val index: Int, val start: String, val end: String, val text: String)

object Srt {
    private val time = Regex("(\\d{2}:\\d{2}:\\d{2}[,.]\\d{3})\\s*-->\\s*(\\d{2}:\\d{2}:\\d{2}[,.]\\d{3})")

    fun parse(raw: String): List<Cue> = raw.replace("\uFEFF", "").trim()
        .split(Regex("\\r?\\n\\s*\\r?\\n"))
        .mapNotNull { block ->
            val lines = block.lines()
            val timeLine = lines.indexOfFirst { time.containsMatchIn(it) }
            if (timeLine < 0) return@mapNotNull null
            val match = time.find(lines[timeLine]) ?: return@mapNotNull null
            val body = lines.drop(timeLine + 1).joinToString("\n").trim()
            if (body.isBlank()) return@mapNotNull null
            Cue(lines.firstOrNull()?.trim()?.toIntOrNull() ?: 0,
                match.groupValues[1].replace(',', '.'), match.groupValues[2].replace(',', '.'), body)
        }.mapIndexed { i, cue -> cue.copy(index = i + 1) }

    fun render(cues: List<Cue>, translated: List<String>, bilingual: Boolean = true): String =
        cues.mapIndexed { i, cue ->
            val fa = translated.getOrNull(i).orEmpty().trim()
            val body = when {
                bilingual && fa.isNotBlank() -> "${cue.text}\n$fa"
                fa.isNotBlank() -> fa
                else -> cue.text
            }
            "${i + 1}\n${cue.start.replace('.', ',')} --> ${cue.end.replace('.', ',')}\n$body"
        }.joinToString("\n\n") + "\n"

    fun timestamp(ms: Long): String {
        val t = ms.coerceAtLeast(0)
        val h = t / 3_600_000
        val m = (t % 3_600_000) / 60_000
        val s = (t % 60_000) / 1_000
        val milli = t % 1_000
        return "%02d:%02d:%02d.%03d".format(h, m, s, milli)
    }
}
