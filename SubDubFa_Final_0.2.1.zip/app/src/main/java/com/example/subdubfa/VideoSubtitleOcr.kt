package com.example.subdubfa

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.Locale

/** Samples the lower portion of a selected video and turns stable OCR readings into timed cues. */
object VideoSubtitleOcr {
    fun scan(context: Context, uri: Uri, intervalMs: Long = 450L, onProgress: (Int) -> Unit): List<Cue> {
        val retriever = MediaMetadataRetriever()
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        try {
            retriever.setDataSource(context, uri)
            val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
                ?: error("مدت ویدئو قابل تشخیص نیست")
            require(duration > 0) { "ویدئوی انتخاب‌شده خالی است" }
            val readings = mutableListOf<Pair<Long, String>>()
            var at = 0L
            while (at < duration) {
                val bitmap = retriever.getFrameAtTime(at * 1000, MediaMetadataRetriever.OPTION_CLOSEST)
                if (bitmap != null) {
                    val cropped = cropSubtitleRegion(bitmap)
                    try {
                        val result = Tasks.await(recognizer.process(InputImage.fromBitmap(cropped, 0)))
                        val text = result.textBlocks.joinToString(" ") { it.text }
                            .replace(Regex("\\s+"), " ").trim()
                        if (isUseful(text)) readings += at to text
                    } finally {
                        if (cropped !== bitmap) cropped.recycle()
                        bitmap.recycle()
                    }
                }
                at += intervalMs
                onProgress(((at * 100) / duration).toInt().coerceIn(0, 100))
            }
            return groupReadings(readings, intervalMs)
        } finally {
            recognizer.close()
            retriever.release()
        }
    }

    private fun cropSubtitleRegion(source: Bitmap): Bitmap {
        // OCR only the bottom 38% where embedded subtitles are commonly placed.
        val top = (source.height * 0.62f).toInt().coerceIn(0, source.height - 1)
        return Bitmap.createBitmap(source, 0, top, source.width, source.height - top)
    }

    private fun isUseful(text: String): Boolean = text.length >= 2 && text.any { it.isLetterOrDigit() }

    private fun normalize(text: String): String = text.lowercase(Locale.ROOT)
        .replace(Regex("[^\\p{L}\\p{N} ]"), "").replace(Regex("\\s+"), " ").trim()

    private fun groupReadings(readings: List<Pair<Long, String>>, interval: Long): List<Cue> {
        if (readings.isEmpty()) return emptyList()
        val groups = mutableListOf<MutableList<Pair<Long, String>>>()
        readings.forEach { item ->
            val last = groups.lastOrNull()
            if (last != null && normalize(last.last().second) == normalize(item.second) && item.first - last.last().first <= interval * 2.5) {
                last += item
            } else groups += mutableListOf(item)
        }
        return groups.mapIndexedNotNull { index, group ->
            val text = group.maxByOrNull { it.second.length }?.second?.trim().orEmpty()
            if (text.length < 2) null else Cue(index + 1,
                Srt.timestamp(group.first().first),
                Srt.timestamp((group.last().first + interval).coerceAtLeast(group.first().first + interval)), text)
        }
    }
}
